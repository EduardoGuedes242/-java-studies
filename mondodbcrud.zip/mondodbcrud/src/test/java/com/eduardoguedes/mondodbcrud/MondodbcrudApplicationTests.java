package com.eduardoguedes.mondodbcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MondodbcrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
