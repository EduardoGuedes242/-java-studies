package com.eduardoguedes.mondodbcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MondodbcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MondodbcrudApplication.class, args);
	}

}
